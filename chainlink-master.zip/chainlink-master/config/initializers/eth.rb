Eth.configure do |config|
  config.tx_data_hex = false
end
