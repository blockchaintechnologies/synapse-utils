FactoryGirl.define do

  factory :json_receiver_request do
    json_receiver
  end

end
