FactoryGirl.define do

  factory :coordinator

end
