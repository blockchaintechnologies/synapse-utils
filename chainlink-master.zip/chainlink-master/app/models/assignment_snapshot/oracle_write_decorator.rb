class AssignmentSnapshot::OracleWrite

end
